library(CellSweeper)
library(SpatialExperiment)
library(SummarizedExperiment)

spe <- make_test_spe(n_cells_per_cluster = 100, n_outliers = 3, seed = 42)

test_that("clusterCellTypes adds cluster labels to colData", {
    result <- clusterCellTypes(spe, resolution = 0.5, regress_covariates = FALSE)
    expect_s4_class(result, "SpatialExperiment")
    expect_true("cell_cluster" %in% colnames(colData(result)))
    # All cells should have a cluster label
    expect_false(any(is.na(colData(result)$cell_cluster)))
})

test_that("clusterCellTypes stores PCA in reducedDims", {
    result <- clusterCellTypes(spe, resolution = 0.5, regress_covariates = FALSE)
    expect_true("PCA" %in% SingleCellExperiment::reducedDimNames(result))
    expect_equal(nrow(SingleCellExperiment::reducedDim(result, "PCA")),
                 ncol(result))
})

test_that("clusterCellTypes use_existing works", {
    spe$my_labels <- rep(c("typeA", "typeB", "typeC"), each = 100)
    result <- clusterCellTypes(spe, use_existing = "my_labels")
    expect_equal(colData(result)$cell_cluster,
                 as.character(spe$my_labels))
})

test_that("clusterCellTypes errors on missing use_existing column", {
    expect_error(
        clusterCellTypes(spe, use_existing = "nonexistent"),
        "not found"
    )
})

test_that("clusterCellTypes handles small clusters", {
    # With very high resolution, some clusters may be small
    result <- clusterCellTypes(spe, resolution = 0.5,
                               min_cluster_size = 200,
                               regress_covariates = FALSE)
    # Small clusters should be labeled "unassigned"
    labels <- colData(result)$cell_cluster
    # At least some cells should have valid cluster labels
    expect_true(any(labels != "unassigned"))
})

test_that("clusterCellTypes skips missing covariates gracefully", {
    expect_message(
        result <- clusterCellTypes(spe,
            covariates = c("sum", "nonexistent_metric"),
            regress_covariates = TRUE),
        "not found"
    )
    expect_true("cell_cluster" %in% colnames(colData(result)))
})

test_that("clusterCellTypes with regress_covariates produces clusters", {
    result <- clusterCellTypes(spe, regress_covariates = TRUE,
                               covariates = c("sum", "detected"))
    expect_true("cell_cluster" %in% colnames(colData(result)))
    labels <- colData(result)$cell_cluster
    expect_true(length(unique(labels)) >= 1)
})

test_that("clusterCellTypes custom cluster_col works", {
    result <- clusterCellTypes(spe, cluster_col = "my_clusters",
                               regress_covariates = FALSE)
    expect_true("my_clusters" %in% colnames(colData(result)))
})

test_that("clusterCellTypes errors on non-SPE input", {
    expect_error(clusterCellTypes(data.frame()), "SpatialExperiment")
})

test_that("clusterCellTypes handles very small datasets", {
    small_spe <- spe[, 1:10]
    expect_warning(
        result <- clusterCellTypes(small_spe, min_cluster_size = 50),
        "Fewer cells"
    )
    expect_true("cell_cluster" %in% colnames(colData(result)))
})
