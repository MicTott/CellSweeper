library(CellSweeper)
library(SpatialExperiment)
library(SummarizedExperiment)

spe <- make_test_spe(n_cells_per_cluster = 50, n_outliers = 3, seed = 42)
spe$cell_cluster <- spe$true_cluster

# Add mock QC columns that plotting functions expect
colData(spe)$sum_zscore <- rnorm(ncol(spe))
colData(spe)$sum_outlier <- abs(colData(spe)$sum_zscore) > 2
colData(spe)$cellsweeper_outlier <- colData(spe)$sum_outlier
colData(spe)$cluster_qc_mahal <- runif(ncol(spe), 0, 10)
colData(spe)$cluster_spatial_homogeneity <- runif(ncol(spe), 0.5, 1)
colData(spe)$cluster_artifact_flag <- FALSE

test_that("plotSpatialOutliers returns ggplot", {
    skip_if_not_installed("ggplot2")
    p <- plotSpatialOutliers(spe, metric = "sum")
    expect_s3_class(p, "ggplot")
})

test_that("plotClusterQC returns ggplot", {
    skip_if_not_installed("ggplot2")
    p <- plotClusterQC(spe, metric = "sum")
    expect_s3_class(p, "ggplot")
})

test_that("plotSpatialDispersion returns ggplot", {
    skip_if_not_installed("ggplot2")
    p <- plotSpatialDispersion(spe)
    expect_s3_class(p, "ggplot")
})

test_that("plotClusterSummary returns list of ggplots", {
    skip_if_not_installed("ggplot2")
    result <- plotClusterSummary(spe, metrics = c("sum"))
    expect_type(result, "list")
    if ("mahalanobis" %in% names(result)) {
        expect_s3_class(result$mahalanobis, "ggplot")
    }
    if ("homogeneity" %in% names(result)) {
        expect_s3_class(result$homogeneity, "ggplot")
    }
})

test_that("plotSpatialOutliers errors on missing metric", {
    skip_if_not_installed("ggplot2")
    expect_error(plotSpatialOutliers(spe, metric = "nonexistent"),
                 "not found")
})

test_that("plotClusterQC errors on missing cluster column", {
    skip_if_not_installed("ggplot2")
    expect_error(plotClusterQC(spe, cluster_col = "nonexistent"),
                 "not found")
})

test_that("plotSpatialOutliers errors on non-SPE", {
    skip_if_not_installed("ggplot2")
    expect_error(plotSpatialOutliers(data.frame()), "SpatialExperiment")
})
