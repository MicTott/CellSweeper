library(CellSweeper)
library(SpatialExperiment)
library(SummarizedExperiment)

spe <- make_test_spe(n_cells_per_cluster = 50, n_outliers = 3, seed = 42)
n_start <- ncol(spe)

test_that("globalFilter removes low-count cells", {
    # Outlier cells have ~2 counts, min_counts = 5 should remove them
    result <- globalFilter(spe, min_counts = 5, min_genes = 1)
    expect_s4_class(result, "SpatialExperiment")
    expect_lt(ncol(result), n_start)
    # All remaining cells should have >= 5 counts
    expect_true(all(result$sum >= 5))
})

test_that("globalFilter removes low-gene cells", {
    result <- globalFilter(spe, min_counts = 1, min_genes = 5)
    expect_s4_class(result, "SpatialExperiment")
    expect_true(all(result$detected >= 5))
})

test_that("globalFilter applies area filters when column exists", {
    result <- globalFilter(spe, min_counts = 1, min_genes = 1,
                           min_area = 20, max_area = 200)
    expect_true(all(colData(result)$cell_area >= 20))
    expect_true(all(colData(result)$cell_area <= 200))
})

test_that("globalFilter skips area filter when column missing", {
    # Remove area column
    spe_no_area <- spe
    colData(spe_no_area)$cell_area <- NULL
    # Should still work, just skip area filtering
    expect_message(
        result <- globalFilter(spe_no_area, min_counts = 1, min_genes = 1,
                               min_area = 20),
        "not found"
    )
    expect_s4_class(result, "SpatialExperiment")
})

test_that("globalFilter adds transcript_density when area exists", {
    result <- globalFilter(spe, min_counts = 1, min_genes = 1)
    expect_true("transcript_density" %in% colnames(colData(result)))
    # Density should be counts / area
    expected <- result$sum / colData(result)$cell_area
    expect_equal(colData(result)$transcript_density, expected)
})

test_that("globalFilter does not add transcript_density when area missing", {
    spe_no_area <- spe
    colData(spe_no_area)$cell_area <- NULL
    colData(spe_no_area)$transcript_density <- NULL
    result <- globalFilter(spe_no_area, min_counts = 1, min_genes = 1)
    expect_false("transcript_density" %in% colnames(colData(result)))
})

test_that("globalFilter passes all cells when thresholds are permissive", {
    result <- globalFilter(spe, min_counts = 0, min_genes = 0)
    expect_equal(ncol(result), n_start)
})

test_that("globalFilter errors on non-SPE input", {
    expect_error(globalFilter(data.frame()), "SpatialExperiment")
})

test_that("globalFilter errors when QC columns missing", {
    spe_bare <- SpatialExperiment(
        assays = list(counts = matrix(1, nrow = 5, ncol = 5)),
        spatialCoords = matrix(rnorm(10), ncol = 2)
    )
    expect_error(globalFilter(spe_bare), "not found")
})
