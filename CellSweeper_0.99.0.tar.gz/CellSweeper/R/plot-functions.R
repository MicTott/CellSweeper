# Suppress R CMD check NOTEs for ggplot2 aes() variables
utils::globalVariables(c(".data", "display_cluster", "cluster_qc_mahal",
                          "cluster_artifact_flag",
                          "cluster_spatial_homogeneity"))

#' Plot Spatial Outliers
#'
#' Creates a spatial scatter plot colored by a QC metric, with outlier cells
#' highlighted.
#'
#' @param spe A \linkS4class{SpatialExperiment} object with QC results from
#'   \code{\link{clusterLocalOutliers}}.
#' @param metric Name of the QC metric to color by (default "sum").
#' @param outlier_col Name of the \code{colData} column with outlier flags
#'   (default "cellsweeper_outlier").
#' @param sample Character. Which sample to plot (default NULL plots first
#'   sample).
#' @param samples Column name for sample IDs (default "sample_id").
#' @param point_size Point size (default 0.5, appropriate for single-cell
#'   data).
#' @param colors Color gradient for the metric (default
#'   \code{c("grey90", "navy")}).
#' @param outlier_color Color for outlier points (default "red").
#' @param outlier_stroke Stroke width for outlier points (default 0.5).
#'
#' @return A ggplot object.
#'
#' @importFrom SummarizedExperiment colData
#' @importFrom SpatialExperiment spatialCoords
#' @importFrom methods is
#'
#' @export
plotSpatialOutliers <- function(spe,
                                metric = "sum",
                                outlier_col = "cellsweeper_outlier",
                                sample = NULL,
                                samples = "sample_id",
                                point_size = 0.5,
                                colors = c("grey90", "navy"),
                                outlier_color = "red",
                                outlier_stroke = 0.5) {

    if (!requireNamespace("ggplot2", quietly = TRUE)) {
        stop("Package 'ggplot2' is required for plotting. ",
             "Install with: install.packages('ggplot2')")
    }

    if (!is(spe, "SpatialExperiment")) {
        stop("'spe' must be a SpatialExperiment object.")
    }

    cd <- as.data.frame(colData(spe))
    coords <- as.data.frame(spatialCoords(spe))
    df <- cbind(coords, cd)

    # Subset to sample
    if (samples %in% colnames(df)) {
        if (is.null(sample)) sample <- df[[samples]][1]
        df <- df[df[[samples]] == sample, ]
    }

    if (!metric %in% colnames(df)) {
        stop("Metric '", metric, "' not found in colData.")
    }

    # Separate outlier and non-outlier
    has_outliers <- outlier_col %in% colnames(df) && any(df[[outlier_col]],
                                                          na.rm = TRUE)
    coord_cols <- colnames(coords)

    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[coord_cols[1]]],
                                           y = .data[[coord_cols[2]]])) +
        ggplot2::geom_point(ggplot2::aes(color = .data[[metric]]),
                            size = point_size) +
        ggplot2::scale_color_gradient(low = colors[1], high = colors[2]) +
        ggplot2::coord_fixed() +
        ggplot2::theme_minimal() +
        ggplot2::labs(title = paste0("Spatial: ", metric),
                      color = metric)

    if (has_outliers) {
        df_outlier <- df[df[[outlier_col]] == TRUE & !is.na(df[[outlier_col]]), ]
        if (nrow(df_outlier) > 0) {
            p <- p + ggplot2::geom_point(
                data = df_outlier,
                ggplot2::aes(x = .data[[coord_cols[1]]],
                             y = .data[[coord_cols[2]]]),
                color = outlier_color, shape = 1,
                size = point_size + 1, stroke = outlier_stroke)
        }
    }

    p
}


#' Plot Per-Cluster QC Distributions
#'
#' Creates violin plots of a QC metric faceted by cluster, showing the
#' distribution within each cluster and highlighting outlier cells.
#'
#' @param spe A \linkS4class{SpatialExperiment} object with cluster labels
#'   and QC results.
#' @param cluster_col Name of the \code{colData} column with cluster labels
#'   (default "cell_cluster").
#' @param metric Name of the QC metric to plot (default "sum").
#' @param outlier_col Name of the outlier flag column (default
#'   \code{paste0(metric, "_outlier")}).
#' @param ncol Number of columns for faceting (default NULL, auto).
#'
#' @return A ggplot object.
#'
#' @importFrom SummarizedExperiment colData
#' @importFrom methods is
#'
#' @export
plotClusterQC <- function(spe,
                          cluster_col = "cell_cluster",
                          metric = "sum",
                          outlier_col = NULL,
                          ncol = NULL) {

    if (!requireNamespace("ggplot2", quietly = TRUE)) {
        stop("Package 'ggplot2' is required for plotting. ",
             "Install with: install.packages('ggplot2')")
    }

    if (!is(spe, "SpatialExperiment")) {
        stop("'spe' must be a SpatialExperiment object.")
    }

    if (is.null(outlier_col)) {
        outlier_col <- paste0(metric, "_outlier")
    }

    cd <- as.data.frame(colData(spe))

    if (!metric %in% colnames(cd)) {
        stop("Metric '", metric, "' not found in colData.")
    }
    if (!cluster_col %in% colnames(cd)) {
        stop("Column '", cluster_col, "' not found in colData.")
    }

    has_outliers <- outlier_col %in% colnames(cd)

    p <- ggplot2::ggplot(cd, ggplot2::aes(x = .data[[cluster_col]],
                                           y = .data[[metric]])) +
        ggplot2::geom_violin(fill = "lightblue", alpha = 0.6) +
        ggplot2::geom_boxplot(width = 0.1, outlier.shape = NA) +
        ggplot2::theme_minimal() +
        ggplot2::labs(title = paste0("Per-cluster: ", metric),
                      x = "Cluster", y = metric) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45,
                                                            hjust = 1))

    if (has_outliers) {
        cd_outlier <- cd[cd[[outlier_col]] == TRUE &
                         !is.na(cd[[outlier_col]]), ]
        if (nrow(cd_outlier) > 0) {
            p <- p + ggplot2::geom_jitter(
                data = cd_outlier,
                ggplot2::aes(x = .data[[cluster_col]],
                             y = .data[[metric]]),
                color = "red", alpha = 0.7, size = 0.8, width = 0.1)
        }
    }

    p
}


#' Plot Spatial Dispersion
#'
#' Creates a spatial scatter plot colored by cluster, with artifact clusters
#' shown in grey.
#'
#' @param spe A \linkS4class{SpatialExperiment} object with cluster labels
#'   and artifact flags.
#' @param cluster_col Name of the cluster label column (default
#'   "cell_cluster").
#' @param highlight_artifacts Logical. Grey out artifact clusters
#'   (default TRUE).
#' @param sample Character. Which sample to plot (default NULL, first sample).
#' @param samples Column name for sample IDs (default "sample_id").
#' @param point_size Point size (default 0.5).
#'
#' @return A ggplot object.
#'
#' @importFrom SummarizedExperiment colData
#' @importFrom SpatialExperiment spatialCoords
#' @importFrom methods is
#'
#' @export
plotSpatialDispersion <- function(spe,
                                  cluster_col = "cell_cluster",
                                  highlight_artifacts = TRUE,
                                  sample = NULL,
                                  samples = "sample_id",
                                  point_size = 0.5) {

    if (!requireNamespace("ggplot2", quietly = TRUE)) {
        stop("Package 'ggplot2' is required for plotting. ",
             "Install with: install.packages('ggplot2')")
    }

    if (!is(spe, "SpatialExperiment")) {
        stop("'spe' must be a SpatialExperiment object.")
    }

    cd <- as.data.frame(colData(spe))
    coords <- as.data.frame(spatialCoords(spe))
    df <- cbind(coords, cd)
    coord_cols <- colnames(coords)

    # Subset to sample
    if (samples %in% colnames(df)) {
        if (is.null(sample)) sample <- df[[samples]][1]
        df <- df[df[[samples]] == sample, ]
    }

    # Create display cluster (grey out artifacts)
    if (highlight_artifacts && "cluster_artifact_flag" %in% colnames(df)) {
        df$display_cluster <- ifelse(
            df$cluster_artifact_flag, "artifact", df[[cluster_col]])
    } else {
        df$display_cluster <- df[[cluster_col]]
    }

    p <- ggplot2::ggplot(df, ggplot2::aes(x = .data[[coord_cols[1]]],
                                           y = .data[[coord_cols[2]]],
                                           color = display_cluster)) +
        ggplot2::geom_point(size = point_size) +
        ggplot2::coord_fixed() +
        ggplot2::theme_minimal() +
        ggplot2::labs(title = "Spatial Dispersion", color = "Cluster")

    # Grey out artifact cluster
    if (highlight_artifacts && "artifact" %in% df$display_cluster) {
        n_real <- length(unique(df$display_cluster[
            df$display_cluster != "artifact"]))
        custom_colors <- c("artifact" = "grey80")
        real_clusters <- setdiff(unique(df$display_cluster), "artifact")
        hue_colors <- grDevices::hcl(
            h = seq(15, 375, length.out = n_real + 1)[seq_len(n_real)],
            c = 100, l = 65)
        p <- p + ggplot2::scale_color_manual(
            values = c(custom_colors,
                       stats::setNames(hue_colors, real_clusters)),
            na.value = "grey50"
        )
    }

    p
}


#' Plot Cluster QC Summary
#'
#' Creates a multi-panel summary of cluster-level QC metrics including
#' Mahalanobis distances and spatial homogeneity scores.
#'
#' @param spe A \linkS4class{SpatialExperiment} object with cluster-level QC
#'   results from \code{\link{flagArtifactClusters}}.
#' @param cluster_col Name of the cluster label column (default
#'   "cell_cluster").
#' @param metrics QC metrics to summarize (default
#'   \code{c("sum", "detected", "subsets_mito_percent")}).
#'
#' @return A list of ggplot objects: \code{$mahalanobis} (bar plot of
#'   Mahalanobis distances), \code{$homogeneity} (bar plot of spatial
#'   homogeneity), \code{$distributions} (violin plots of selected metrics).
#'
#' @importFrom SummarizedExperiment colData
#' @importFrom methods is
#'
#' @export
plotClusterSummary <- function(spe,
                               cluster_col = "cell_cluster",
                               metrics = c("sum", "detected",
                                           "subsets_mito_percent")) {

    if (!requireNamespace("ggplot2", quietly = TRUE)) {
        stop("Package 'ggplot2' is required for plotting. ",
             "Install with: install.packages('ggplot2')")
    }

    if (!is(spe, "SpatialExperiment")) {
        stop("'spe' must be a SpatialExperiment object.")
    }

    cd <- as.data.frame(colData(spe))

    if (!cluster_col %in% colnames(cd)) {
        stop("Column '", cluster_col, "' not found in colData.")
    }

    plots <- list()

    # --- Mahalanobis distance bar plot ---
    if ("cluster_qc_mahal" %in% colnames(cd)) {
        mahal_df <- unique(cd[, c(cluster_col, "cluster_qc_mahal",
                                   "cluster_artifact_flag")])

        plots$mahalanobis <- ggplot2::ggplot(
            mahal_df,
            ggplot2::aes(x = stats::reorder(.data[[cluster_col]],
                                             cluster_qc_mahal),
                         y = cluster_qc_mahal,
                         fill = cluster_artifact_flag)) +
            ggplot2::geom_col() +
            ggplot2::scale_fill_manual(values = c("FALSE" = "steelblue",
                                                   "TRUE" = "firebrick")) +
            ggplot2::coord_flip() +
            ggplot2::theme_minimal() +
            ggplot2::labs(title = "Cluster Mahalanobis Distance",
                          x = "Cluster", y = "Mahalanobis Distance",
                          fill = "Artifact")
    }

    # --- Spatial homogeneity bar plot ---
    if ("cluster_spatial_homogeneity" %in% colnames(cd)) {
        homo_df <- unique(cd[, c(cluster_col, "cluster_spatial_homogeneity",
                                  "cluster_artifact_flag")])

        plots$homogeneity <- ggplot2::ggplot(
            homo_df,
            ggplot2::aes(x = stats::reorder(.data[[cluster_col]],
                                             cluster_spatial_homogeneity),
                         y = cluster_spatial_homogeneity,
                         fill = cluster_artifact_flag)) +
            ggplot2::geom_col() +
            ggplot2::scale_fill_manual(values = c("FALSE" = "steelblue",
                                                   "TRUE" = "firebrick")) +
            ggplot2::coord_flip() +
            ggplot2::theme_minimal() +
            ggplot2::labs(title = "Cluster Spatial Homogeneity",
                          x = "Cluster", y = "Neighborhood Homogeneity",
                          fill = "Artifact")
    }

    # --- Metric distributions per cluster ---
    available_metrics <- intersect(metrics, colnames(cd))
    if (length(available_metrics) > 0) {
        plots$distributions <- lapply(available_metrics, function(m) {
            plotClusterQC(spe, cluster_col = cluster_col, metric = m)
        })
        names(plots$distributions) <- available_metrics
    }

    plots
}
